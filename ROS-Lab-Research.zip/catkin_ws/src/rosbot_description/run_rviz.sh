#!/bin/bash

roslaunch rosbot_description rosbot_rviz_gmapping.launch

