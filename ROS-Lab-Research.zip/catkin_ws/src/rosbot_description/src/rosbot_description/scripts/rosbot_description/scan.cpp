#include "ros/ros.h"
#include "std_msgs/String.h"
//#include "sensor_msgs/LaserScan.h"
#include "geometry_msgs/Twist.h"
#include <iostream>
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Pose.h"

using namespace std;

ros::Publisher pub; 
ros::Subscriber sub; 
geometry_msgs::Twist msg;

void moveForward()
{
  cout << "Forward" << endl;
  msg.linear.x = 1;
  msg.angular.z = 0;
  pub.publish(msg);
  usleep(10);
}
void moveLeft(){
  cout << "Left" << endl;
  msg.linear.x = 0.6;
  msg.angular.z = 0.9;
  pub.publish(msg);
  usleep(10);
}
void moveRight(){
  cout << "Right" << endl;
  msg.linear.x = 0.6;
  msg.angular.z = -0.9;
  pub.publish(msg);
  usleep(10);
}

void scan_rosbot(){
  for (int i = 0; i < 5; i++)
  {
    sleep (1);

    moveForward();
    sleep(5);

    moveRight();
    sleep(5);

    moveForward();
    sleep(5);

    moveLeft();
    sleep(4);

  }

}

int main(int argc, char **argv){

  ros::init(argc, argv, "scan_robot");
  ros::NodeHandle n;
  pub = n.advertise<geometry_msgs::Twist>("/cmd_vel", 100);
  scan_rosbot();
  ros::spin();
  return 0;
}
