#!/bin/bash

roslaunch rosbot_navigation rosbot_teleop.launch