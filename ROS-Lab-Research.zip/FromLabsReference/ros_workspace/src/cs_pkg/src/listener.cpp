/*

this code show the ranges of the lidar sensor 

 #include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"
#define radians2degrees(x) ((x)*180./M_PI)

void processLaserScan(const sensor_msgs::LaserScan::ConstPtr& scan)
{
	int count = scan -> scan_time / scan -> time_increment;


	ROS_INFO("range_min, %f", scan -> range_min);
        ROS_INFO("range_max, %f", scan -> range_max);


}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "rplidar_node_client");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe<sensor_msgs::LaserScan>("/scan", 100, processLaserScan);
	ros::spin();
	
	return 0;
}
*/


/* this code */ 
#include "ros/ros.h"
#include "sensor_msgs/LaserScan.h"

#define radians2degrees(x) ((x)*180./M_PI)

void processLaserScan(const sensor_msgs::LaserScan::ConstPtr& scan)
{
	int count = scan -> scan_time / scan -> time_increment;

 	printf("Laser Scan Reading: %s[%d] \n", scan->header.frame_id.c_str(), count);
	printf("angle_range, %f, %f", radians2degrees(scan -> angle_min), radians2degrees(scan -> angle_max));


	for(int i = 0; i< count; i++) {
		float degree = radians2degrees(scan -> angle_min + scan -> angle_increment * i);
		printf(": [%f, %f]", degree, scan -> ranges[i]);
	}	
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "rplidar_node_client");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe<sensor_msgs::LaserScan>("/scan", 100, processLaserScan);
	ros::spin();
	
	return 0;
}




