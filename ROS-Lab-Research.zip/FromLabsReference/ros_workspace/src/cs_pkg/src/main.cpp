#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include "tf/transform_listener.h"
#include <cstdio>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h> 
#include <iostream>
#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Pose.h"
#include "math.h"

using namespace std;

ros::Publisher pub;

ros::Subscriber sub;

geometry_msgs::Twist msg;


float x_pos=0, y_pos=0, z_pos=0,theta=0,s,delta_f,theta_c,f,fx,fy, theta_obs1=0, x_object=0, y_object= -0.3, U1, U2, U3, U4, U5, U6, U7;
float x_pos_square = x_pos*x_pos;
float y_pos_square = y_pos*y_pos;


 

void move_left(int x){

    std::cout<< "left" << std::endl;

    msg.linear.x = 0.1;

    msg.angular.z = 0.5;

    pub.publish(msg);
    
    for(int i=0;i<x;i++){    	
     sleep(1);
     pub.publish(msg);
    }

}

void right(int x){

    std::cout<< "right" << std::endl;

    msg.linear.x = 0.1;

    msg.angular.z = -0.5; ///.

    pub.publish(msg);
    
    for(int i=0;i<x;i++){    	
     sleep(1);
     pub.publish(msg);
    }
}


 

void forward(int x){

    std::cout<< "forward" << std::endl;

    msg.angular.z = 0.0;

    msg.linear.x = 0.5;

    pub.publish(msg);

    for(int i=0;i<x;i++){    	
     sleep(1);
     pub.publish(msg);
    }

}

void stop(int x){

    std::cout<< "stop" << std::endl;

    msg.angular.z = 0.0;

    msg.linear.x = 0.0;

    pub.publish(msg);

    for(int i=0;i<x;i++){    	
     sleep(1);
     pub.publish(msg);
    }

}


//bool once = true;


void simple_move()

{

	for (int x=0;x<4;x++){
  	forward(5);
	pub.publish(msg);
	
    	stop(2);
	pub.publish(msg);

	right(5);//5 is good
	pub.publish(msg);

	stop(2);
	pub.publish(msg);
	}

}

  void circle (int radius, int time){
    std::cout<< "circle" << std::endl;
    msg.linear.x = 0.1;
    msg.angular.z = ((2*3.14*radius)/90);
    pub.publish(msg);
    
    for(int i=0;i<time;i++){    	
     sleep(1);
     pub.publish(msg);

    }
	
     stop(2);
     pub.publish(msg);
}	



void odomcallback(const nav_msgs::Odometry::ConstPtr& msg)
{ //inital robot position 
 
 ROS_INFO("Position-> x: [%f], y: [%f], z: [%f]", msg->pose.pose.position.x,msg->pose.pose.position.y, msg->pose.pose.position.z);
 

  	x_pos=msg->pose.pose.position.x;
	y_pos=msg->pose.pose.position.y;
  	z_pos=msg->pose.pose.orientation.z;

//ROS_INFO("First robot position: [%f,%f]", odom->pose.pose.position.x, odom->pose.pose.position.y);

}


void movePath(int time){

	//msg.linear.y = .5;
	msg.linear.x = .5;
    	pub.publish(msg);
	
 for(int i=0;i<time;i++){    	
     sleep(1);
     pub.publish(msg);

    }

	
}
int main(int argc, char** argv)

{

    ros::init(argc, argv, "wfnode");

    ros::NodeHandle n;

    pub = n.advertise<geometry_msgs::Twist>("/cmd_vel", 100);

    sub = n.subscribe("/odom", 1000, odomcallback);
  
	
    //ros::Duration time_between_ros_wakeups(0.001);

	while (ros::ok()) {
		geometry_msgs::Twist roomba_vel;
		//geometry_msgs::Twist msg;
		//movePath(10);

		double K1 = .4;

		double K2 = .4;
		
 		roomba_vel.linear.x = 1.0;

		roomba_vel.linear.y = 0;
		double f = x_pos*x_pos + y_pos*y_pos;

		double s=K2*(f)/sqrt(1+(f*f));

		roomba_vel.angular.z = K1 * ( fabs (roomba_vel.linear.x) * cos (theta)- fabs (roomba_vel.linear.x) * sin (theta))+ theta_c;
//roomba_vel.angular.z = K1 * (-sqrt(4*x_pos*x_pos + 4*y_pos*y_pos) * roomba_vel.linear.x * s - (2*x_pos) * fabs (roomba_vel.linear.x) * cos (theta)
									 //- (2*y_pos) * fabs (roomba_vel.linear.x) * sin (theta))+ theta_c;


		pub.publish(roomba_vel);
		//pub.publish(msg);


		ros::spinOnce(); 


	

    	}
    	return 0;

}




