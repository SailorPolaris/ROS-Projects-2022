#include <cstdio>
#include <string>
#include <fstream>
#include <stdio.h>
#include <stdlib.h> 
#include <iostream>
#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Pose.h"
#include "math.h"


using namespace std;
float x_pos=0, y_pos=0, z_pos=0,theta=0,s,delta_f,theta_c,f,fx,fy, theta_obs1=0, x_object=0, y_object= -0.3, U1, U2, U3, U4, U5, U6, U7;
float x_pos_square = x_pos*x_pos;
float y_pos_square = y_pos*y_pos;



void odomcallback(const nav_msgs::Odometry::ConstsPtr& odom)
{ //inital robot position (X,Y,Z) --need 
 

 theta = 2 * atan2(odom->pose.pose.orientation.z,odom->pose.pose.orientation.w); 
  	x_pos=odom->pose.pose.position.x;
	y_pos=odom->pose.pose.position.y;
  	z_pos=odom->pose.pose.orientation.z;
ROS_INFO("First robot position: [%f,%f]", odom->pose.pose.position.x, odom->pose.pose.position.y);

}

void odomcallback1(const nav_msgs::Odometry::ConstPtr& odom)
{// inital position for 2 robot (X2,Y2,Z2)  -- no need 
 
 theta_obs1 = 2 * atan2(odom->pose.pose.orientation.z,odom->pose.pose.orientation.w); 
  	x_object=odom->pose.pose.position.x;
	y_object=odom->pose.pose.position.y;
ROS_INFO("Second Robot Position: [%f,%f]", x_object, y_object);
}



int main (int argc, char** argv)
{
   int counter=0;
   ros::init(argc, argv, "circle_IPM");
   ros::NodeHandle n;
   ros::Publisher create_pub = n.advertise<geometry_msgs::Twist>("cmd_vel_ex1", 1);
   ros::Subscriber sub_odom = n.subscribe("odom_ex1", 1000, odomcallback);
   ros::Subscriber sub_odom1 = n.subscribe("odom4", 1000, odomcallback1);


///////////////// Gaussian Function /////////////////////////////

char fileName[] = "/home/exercise/Desktop/journal/circle_IPM_1";
FILE * s1;

s1 = fopen(fileName, "w");

float sigma = 0.8;
float A = 1;


  while (ros::ok())
  {
    counter++;
    geometry_msgs::Twist roomba_vel;
 
 
float B = (((x_pos - x_object) * (x_pos - x_object)) + ((y_pos - y_object) * (y_pos - y_object))) / (sigma * sigma);
float Obs = A * exp (-B);
float f2 = Obs;

roomba_vel.linear.x = 0.1; 
 

   
double K1 = 10; 
double K2 = 1.5;

// circle with Gaussian


double f= ((x_pos*x_pos) + (y_pos*y_pos) - 0.09) + Obs;    //CIRCLE
double s=K2*(f)/sqrt(4+(f*f)); 

float U1 = Obs;
float U2 = (-2 / (sigma * sigma)) * (x_pos - x_object);
float U3 = (-2 / (sigma * sigma));
float U4 = (-2 / (sigma * sigma)) * (y_pos - y_object);
float U5 = U1 * (-2 / (sigma * sigma)) * (y_pos - y_object);

float fx = (2*x_pos) + (U1 * U2);
//float fy = (2*y_pos+2) + (U1 * U4);
float fy = (2*y_pos) + (U1 * U4);

float fxx = (U1 * U3) + ((U2 * U2) * U1) + 2;
float fyy = (U1 * U3) + ((U4 * U4) * U1) + 2;
float fxy = U2 * U5;

float delta_f = sqrt ((fx * fx) + (fy * fy));


double theta_c = 0; // (((fx) * (fxy)) - ((fy) * (fxx)) * (roomba_vel.linear.x)* cos (theta) + ((fy) * (fyy)) - ((fy) * (fxy)) * (roomba_vel.linear.x)* sin (theta)) / delta_f;


roomba_vel.angular.z = K1 * (((-(delta_f)) * roomba_vel.linear.x * s) - ((fx) * fabs (roomba_vel.linear.x) * cos (theta)) - ((fy) * fabs (roomba_vel.linear.x) * sin (theta))) + theta_c; // circle



    create_pub.publish(roomba_vel); 
    ros::spinOnce();
   if (counter==1500)
	{ 
//fprintf(s1, "%8.5f %8.5f %8.5f %8.5f\n", x_pos, y_pos, theta, f);
fprintf(s1, "%8.5f %8.5f %8.5f %8.5f %8.5f %8.5f %8.5f %8.5f\n", x_pos, y_pos, theta, f, x_object, y_object, theta_obs1, f2);
cout << x_object << y_object << endl;

counter=0;
}
} 
fclose(s1);

return 0;
}
